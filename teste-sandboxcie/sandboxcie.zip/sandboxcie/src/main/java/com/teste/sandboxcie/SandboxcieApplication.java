package com.teste.sandboxcie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SandboxcieApplication {

	public static void main(String[] args) {
		SpringApplication.run(SandboxcieApplication.class, args);
	}

}
