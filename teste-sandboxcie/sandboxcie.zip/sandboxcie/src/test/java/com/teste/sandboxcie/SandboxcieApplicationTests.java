package com.teste.sandboxcie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SandboxcieApplicationTests {

	@Test
	void contextLoads() {
	}

}
